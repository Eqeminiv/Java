package laborki;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.io.File;

public class Main {

	public static void main(String[] args) throws IOException{
		//FileInputStream znak po znaku
//		FileInputStream in = null;
//	      FileOutputStream out = null;
//
//	      try {
//	         in = new FileInputStream("input.txt");
//	         out = new FileOutputStream("output.txt");
//	         
//	         int c;
//	         while ((c = in.read()) != -1) {
//	            out.write(c);
//	         }
//	      }finally {
//	         if (in != null) {
//	            in.close();
//	         }
//	         if (out != null) {
//	            out.close();
//	         }
//	      }
//		
		
		//FileReader tablicowo
//		  FileReader in = null;
//	      FileWriter out = null;
//	      char tablica[] = new char[10];
//
//	      try {
//	         in = new FileReader("input.txt");
//	         out = new FileWriter("output.txt");
//	         
//	         int c;
//	         while ((c=in.read(tablica)) != -1) {
//	            out.write(tablica, 0, c);
//	         }
//	      }finally {
//	         if (in != null) {
//	            in.close();
//	         }
//	         if (out != null) {
//	            out.close();
//	         }
//	      }

		//byte
//		try {
//	         byte bWrite [] = {65,48,50,40,38};
//	         OutputStream os = new FileOutputStream("test.txt");
//	         for(int x = 0; x < bWrite.length ; x++) {
//	            os.write( bWrite[x] );   // writes the bytes
//	         }
//	         os.close();
//	     
//	         InputStream is = new FileInputStream("test.txt");
//	         int size = is.available();
//
//	         for(int i = 0; i < size; i++) {
//	            System.out.print((char)is.read() + "  ");
//	         }
//	         is.close();
//	      } catch (IOException e) {
//	         System.out.print("Exception");
//	      }	
		
		//tworzenie sciezki		
//		String dirname = "d:\\tmp";
//		File d = new File(dirname);
//		d.mkdirs();
		
		  FileReader in = null;
	      FileWriter out = null;

	      try {
	         in = new FileReader("zadanie.txt");
	         
	         int c;
	         int licznik = 0;
//	         char znaki[] = new char[26];
//	         for (int i=97;i<123;i++)
//	         {
//	        	 znaki[i-97] = (char)i;
//	        	 System.out.print(znaki[i-97]);
//	         }
	         for(int i=97;i<123;i++)
	         {
	        	 System.out.print((char)i);
	        	 while((c=in.read()) != -1)
	        	 {
	        		 if(c == i)
	        		 {
	        			 licznik++;
	        		 }
	        	 }
	        	 for(int j=0;j<licznik;j++)
        		 {
	        		 System.out.print("*");
        		 }
	        	 System.out.print("\n");
	        	 licznik=0;
        		 }
	        	 
	         }
	         

	         
	      finally {
	         if (in != null) {
	            in.close();
	         }
	      }
		
	}

}
