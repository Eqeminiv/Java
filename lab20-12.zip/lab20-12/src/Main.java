
public class Main {

	public static void main(String[] args) {
		Person a = new Person("Jan", "Kowalski",1990);
		System.out.println(a.toString());
		
		Person b = new Student("Andrzej", "Nowak", 1990, 111111);
		System.out.println(b.toString());
		
		Student c = new Student("Larry", "Laffer", 1880, 123456);
		System.out.println(c.toString());
		


	}

}