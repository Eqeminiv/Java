
public class Student extends Person{
	private int index;

	public Student(String name, String surname, int yearOfBirth, int index)
	{
		super(name, surname, yearOfBirth);
		this.index = index;
	}
	


@Override
	public String toString()
	{
		return super.toString() + ", indeks: " + index;
	}

	public int getIndex()
	{
		return this.index;
	}

@Override
	public boolean equals(Object obj)
	{
	if (this == obj)
		return true;
	else
	{
		if (obj == null)
			return false;
		else
		{
			if (this.getClass() != obj.getClass())
				return false;
			else
			{
				Student a = (Student)obj;
				if(this.getName() == a.getName() && this.getSurname() == a.getSurname() &&
						this.getIndex() == a.getIndex() && this.getYearOfBirth() == this.getYearOfBirth())
				{
					return true;
				}
				else
				{
					return false;}
			}
		}
	}
	
		return true;
	}
}
