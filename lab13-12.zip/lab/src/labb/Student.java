package labb;

public class Student {
	private Osoba a;
	private int nrIndeksu;
	
	public Student()
	{
		a = new Osoba();
		nrIndeksu = 0;
	}
	
	public Student(Osoba s, int indeks)
	{
		a = s;
		nrIndeksu = indeks; // D O K O N C Z
	}
	public Student(Student b)
	{
		//this.a = new Osoba(b.getImie(), b.getNazwisko(), b.getWiek());
		this.a = new Osoba(b.a);
		nrIndeksu = b.nrIndeksu;
	}
	
	public String getImie(Osoba c)
	{
		return c.getImie();
	}
	
	public String getNazwisko(Osoba c)
	{
		return c.getNazwisko();
	}
	
	public int getWiek(Osoba c)
	{
		return c.getWiek();
	}
	
	public
}
