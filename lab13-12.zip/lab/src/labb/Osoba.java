package labb;


public class Osoba {
	private String imie;
	private String nazwisko;
	private int wiek;
	public static int licznik; //moze byc zamiast konstruktora po prostu '=0'
	static
	{
		licznik = 0;
	}
	
	public Osoba()
	{
		imie = "brak";
		nazwisko = "brak";
		wiek = 0;
		licznik++;
	}
	
	public Osoba(String imie)
	{
		this(imie, "brak"); //lista inicjalizacyjna
	}
	public Osoba(String imie, String nazwisko)
	{
		this(imie, nazwisko, 0); //lista inicjalizacyjna
	}
	public Osoba(String imie, String nazwisko, int wiek)
	{
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.wiek = wiek;
		licznik++;
		
	}
	public Osoba(Osoba a) {
		this.imie = a.imie;
		this.nazwisko = a.nazwisko;
		this.wiek = a.wiek;
	}

	public String wypiszImie() {
		return this.imie + " " + this.nazwisko + ". Lat: " + this.wiek;
	}
	public int wypiszLicznik()
	{
		return licznik;
	}
	
	public String getImie()
	{
		return imie;
	}
	
	public String getNazwisko()
	{
		return nazwisko;
	}
	
	public int getWiek()
	{
		return wiek;
	}

}
