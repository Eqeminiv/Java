package labb;

public class Main {
	
	public static void main(String[] args) {
		Osoba a = new Osoba("Jan", "Kowalski");
		System.out.println(a.wypiszImie());
		Osoba b = new Osoba();
		System.out.println(a.wypiszLicznik());
		
		Student przyklad = new Student();
		Student kopia = new Student(przyklad);

	}

}
